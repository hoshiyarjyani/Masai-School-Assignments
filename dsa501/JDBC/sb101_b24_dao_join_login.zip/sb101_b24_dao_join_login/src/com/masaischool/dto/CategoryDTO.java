package com.masaischool.dto;

public interface CategoryDTO {
	public String getCatId();
	public void setCatId(String catId);
	public String getCatName();
	public void setCatName(String catName);
}
