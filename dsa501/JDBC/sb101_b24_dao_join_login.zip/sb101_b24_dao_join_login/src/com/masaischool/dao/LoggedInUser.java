package com.masaischool.dao;

public class LoggedInUser {
	static int loggedInUserId;
}
