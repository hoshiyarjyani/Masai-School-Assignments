package com.masaischool.exception;

public class SomethingWentWrongException extends Exception {
	public SomethingWentWrongException(String message) {
		super(message);
	}
}
